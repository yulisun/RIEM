this is a new verion of wrapper 
that allows to set pairwise terms in a form of a |E|x6 list :
[n1 n2 e00 e01 e10 e11]